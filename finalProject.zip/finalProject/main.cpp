#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <GL/glut.h>
#include <iostream>
using namespace std;

float c1xp=0.0,c1yp=0.0,c1zp=0.0;
float c2xp=0.0,c2yp=0.0,c2zp=0.0;
float p1xp=0.0,p1yp=0.0,p1zp=0.0;
float p1sxp=0.0,p1syp=0.0,p1szp=0.0;
float x=1.0;
float rxp=0.0,ryp=0.0,rzp=0.0;
float r=0.0;

float width=-940,width2=600,width3=2000;

int dnr=103,dng=155,dnb=176;
int ldr=255,ldg=255,ldb=255;
int sdr=246,sdg=171,sdb=26;
int cdr=230,cdg=234,cdb=237;
int gdr=100,gdg=171,gdb=55;
int m1r=103,m1g=155,m1b=176;
int m2r=103,m2g=155,m2b=176;
int m=0;



void Sky()
{
        glPushMatrix();
        glColor3ub(dnr,dng,dnb);
        glBegin(GL_QUADS);
        glVertex2i(0,500);
        glVertex2i(902,500);
        glVertex2i(902,0);
        glVertex2i(0,0);
        glEnd();
        glPopMatrix();

        glutPostRedisplay();
}


void myInit (void)
{
        glClearColor(1.0, 1.0, 1.0, 0.0);
        glColor3f(0.0f, 0.0f, 0.0f);
        glPointSize(4.0);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluOrtho2D(0.0, 902.0, 0.0, 684.0);
}


// HOSPITAL PART

void HospitalWindow1(int x,int y)
{
    glPushMatrix();
    glColor3ub(0,0,0);
    glBegin(GL_QUADS);
    glVertex2i(x,y);
    glVertex2i(x+16,y);
    glVertex2i(x+16,y+30);
    glVertex2i(x,y+30);
    glEnd();
    glPopMatrix();
}

void HospitalMidWindow1(int x,int y)
{
    glPushMatrix();
    glColor3ub(0,0,0);
    glBegin(GL_QUADS);
    glVertex2i(x,y);
    glVertex2i(x+12,y);
    glVertex2i(x+12,y+18);
    glVertex2i(x,y+18);
    glEnd();
    glPopMatrix();
}

void Hospital()
{
    glPushMatrix();
    glColor3ub(252,222,66);
    glBegin(GL_QUADS);
    glVertex2i(151,257);
    glVertex2i(181,257);
    glVertex2i(181,424);
    glVertex2i(151,424);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(252,222,66);
    glBegin(GL_QUADS);
    glVertex2i(449,257);
    glVertex2i(449,424);
    glVertex2i(420,424);
    glVertex2i(420,257);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(252,222,66);
    glBegin(GL_QUADS);
    glVertex2i(181,381);
    glVertex2i(420,381);
    glVertex2i(420,400);
    glVertex2i(181,400);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(190,27,9);
    glBegin(GL_QUADS);
    glVertex2i(181,258);
    glVertex2i(420,258);
    glVertex2i(420,381);
    glVertex2i(181,381);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,255,255);
    glBegin(GL_QUADS);
    glVertex2i(151,390);
    glVertex2i(181,390);
    glVertex2i(181,401);
    glVertex2i(151,401);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,255,255);
    glBegin(GL_QUADS);
    glVertex2i(420,390);
    glVertex2i(449,390);
    glVertex2i(449,401);
    glVertex2i(420,401);
    glEnd();
    glPopMatrix();

    int HospitalStripe1=163;
    for(int i=11;i>=0;i--)
    {
        HospitalStripe1+=20;
        HospitalWindow1(HospitalStripe1,349);
    }

    int HospitalStripe2=163;
    for(int i=11;i>=0;i--)
    {
        HospitalStripe2+=20;
        HospitalWindow1(HospitalStripe2,315);
    }

    int HospitalStripe3=163;
    for(int i=11;i>=0;i--)
    {
        HospitalStripe3+=20;
        HospitalWindow1(HospitalStripe3,281);
    }

    glPushMatrix(); //middle long stripe
    glColor3ub(252,222,66);
    glBegin(GL_QUADS);
    glVertex2i(263,257);
    glVertex2i(339,257);
    glVertex2i(339,400);
    glVertex2i(263,400);
    glEnd();
    glPopMatrix();

    int HospitalStripe4=260;
    for(int i=3;i>=0;i--)
    {
        HospitalStripe4+=14;
        HospitalMidWindow1(HospitalStripe4,370);
    }

    int HospitalStripe5=260;
    for(int i=3;i>=0;i--)
    {
        HospitalStripe5+=14;
        HospitalMidWindow1(HospitalStripe5,340);
    }

     int HospitalStripe6=260;
    for(int i=3;i>=0;i--)
    {
        HospitalStripe6+=14;
        HospitalMidWindow1(HospitalStripe6,310);
    }

    glPushMatrix();  //Door
    glColor3ub(0,0,0);
    glBegin(GL_QUADS);
    glVertex2i(286,257);
    glVertex2i(318,257);
    glVertex2i(318,298);
    glVertex2i(286,298);
    glEnd();
    glPopMatrix();

    glutPostRedisplay();
}



// School part

void SchoolWindow1(int x,int y)
{
    glPushMatrix();
    glColor3ub(190,202,200);
    glBegin(GL_QUADS);
    glVertex2i(x,y);
    glVertex2i(x+20,y);
    glVertex2i(x+20,y+17);
    glVertex2i(x,y+17);
    glEnd();
    glPopMatrix();
}

void School()
{
    glPushMatrix();
    glColor3ub(214,130,5);
    glBegin(GL_QUADS);
    glVertex2i(643,257);
    glVertex2i(884,257);
    glVertex2i(884,351);
    glVertex2i(643,351);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(73,3,5);
    glBegin(GL_QUADS);
    glVertex2i(640,351);
    glVertex2i(887,351);
    glVertex2i(887,358);
    glVertex2i(640,358);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(80,149,146);
    glBegin(GL_QUADS);
    glVertex2i(648,265);
    glVertex2i(719,265);
    glVertex2i(719,275);
    glVertex2i(648,275);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(80,149,146);
    glBegin(GL_QUADS);
    glVertex2i(808,265);
    glVertex2i(879,265);
    glVertex2i(879,275);
    glVertex2i(808,275);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(217,132,3);
    glBegin(GL_POLYGON);
    glVertex2i(713,358);
    glVertex2i(813,358);
    glVertex2i(813,381);
    glVertex2i(763,402);
    glVertex2i(713,381);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(75,3,4);
    glBegin(GL_TRIANGLES);
    glVertex2i(707,381);
    glVertex2i(819,381);
    glVertex2i(763,409);
    glEnd();
    glPopMatrix();

    glColor3ub(200,200,240);

    int SchoolStripe1=623;
    for(int i=2;i>=0;i--)
    {
        SchoolStripe1+=25;
        SchoolWindow1(SchoolStripe1,328);
    }

     int SchoolStripe2=623;
    for(int i=2;i>=0;i--)
    {
        SchoolStripe2+=25;
        SchoolWindow1(SchoolStripe2,304);
    }

    int SchoolStripe3=623;
    for(int i=2;i>=0;i--)
    {
        SchoolStripe3+=25;
        SchoolWindow1(SchoolStripe3,281);
    }

    int SchoolStripe4=783;
    for(int i=2;i>=0;i--)
    {
        SchoolStripe4+=25;
        SchoolWindow1(SchoolStripe4,328);
    }

    int SchoolStripe5=783;
    for(int i=2;i>=0;i--)
    {
        SchoolStripe5+=25;
        SchoolWindow1(SchoolStripe5,304);
    }

    int SchoolStripe6=783;
    for(int i=2;i>=0;i--)
    {
        SchoolStripe6+=25;
        SchoolWindow1(SchoolStripe6,282);
    }

}
void SchoolDoor()
{
    glPushMatrix();
    glColor3ub(72,2,4);
    glBegin(GL_QUADS);
    glVertex2i(728,257);
    glVertex2i(797,257);
    glVertex2i(797,321);
    glVertex2i(728,321);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(75,3,4);
    glBegin(GL_TRIANGLES);
    glVertex2i(722,321);
    glVertex2i(803,321);
    glVertex2i(763,347);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(100,150,100);
    glBegin(GL_QUADS);
    glVertex2i(733,304);
    glVertex2i(792,304);
    glVertex2i(792,321);
    glVertex2i(733,321);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(89,107,121);
    glBegin(GL_QUADS);
    glVertex2i(743,257);
    glVertex2i(782,257);
    glVertex2i(782,295);
    glVertex2i(743,295);
    glEnd();
    glPopMatrix();
}





float cdxp1=0.0;
float cdxp2=0.0;
float cdxp3=0.0;


void Road()
{
    glPushMatrix();
    glColor3ub(0,0,0);
    glBegin(GL_QUADS);
    glVertex2i(0,148);
    glVertex2i(902,148);
    glVertex2i(902,47);
    glVertex2i(0,47);
    glEnd();
    glPopMatrix();

    // road divider
    glPushMatrix();
    glColor3ub(255,255,255);
    glBegin(GL_QUADS);
    glVertex2i(0,95);
    glVertex2i(902,95);
    glVertex2i(902,100);
    glVertex2i(0,100);
    glEnd();
    glPopMatrix();

}

void RoadGrash()
{
    glPushMatrix();
    glColor3ub(gdr,gdg,gdb);
    glBegin(GL_QUADS);
    glVertex3f(0.0,0.0,0.0);
    glVertex3f(902.0,0.0,0.0);
    glVertex3f(902.0,47.0,0.0);
    glVertex3f(0.0,47.0,0.0);
    glEnd();
    glPopMatrix();
}

void BetweenRoadAndBuldings()
{
    glPushMatrix();
    glColor3ub(gdr,gdg,gdb);

    glBegin(GL_QUADS);
        glVertex3f(0.0,57.0,0.0);
        glVertex3f(902.0,57.0,0.0);
        glVertex3f(902.0,258.0,0.0);
        glVertex3f(0.0,258.0,0.0);
    glEnd();

    glPopMatrix();
}






void myDisplay(void)
{
    glClear(GL_COLOR_BUFFER_BIT);

    Sky();
    Hospital();

    School();
    SchoolDoor();

    BetweenRoadAndBuldings();
    Road();
    RoadGrash();


    glFlush ();
    glutSwapBuffers();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (902,684);
    glutInitWindowPosition (250, 30);
    glutCreateWindow ("City View");
    glutDisplayFunc(myDisplay);

    myInit ();
    glutMainLoop();
}
